import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import time
import sys

# =============================================================================
# 1. PARÂMETROS DO ANALISADOR DE ESPECTRO (LARGURA DE BANDA TOTAL)
# =============================================================================
FREQ_START = 100_000_000 #10000000      # 10 MHz
FREQ_STOP  = 300_000_000 #1700000000    # 1700 MHz (1.7 GHz)

# Largura de banda instantânea por salto (Usando 40 MHz para varredura rápida)
# O bladeRF 2.0 Micro suporta até 56 MHz, mas 40 MHz oferece excelente linearidade no chip AD9361
STEP_BANDWIDTH = 40000000  # 40 MHz
SAMPLE_RATE    = 40000000  # 40 Msps

# Configurações de Resolução de FFT por salto
NUM_SAMPLES = 2048         # Tamanho da FFT por bloco
BUFFER_BYTES = NUM_SAMPLES * 4
GAIN = 0                  # Ganho em dB

# =============================================================================
# 2. CÁLCULO DA GRADE DE VARREDURA (FREQUÊNCIAS DE SALTO)
# =============================================================================
# Calcula os pontos centrais de frequência onde o bladeRF precisará sintonizar
half_step = STEP_BANDWIDTH / 2
sweep_centers = np.arange(FREQ_START + half_step, FREQ_STOP, STEP_BANDWIDTH)
# Garante que o último bloco cubra até o limite final solicitado
if sweep_centers[-1] + half_step < FREQ_STOP:
    sweep_centers = np.append(sweep_centers, FREQ_STOP - half_step)

num_steps = len(sweep_centers)
print(f"--- Configuração do Analisador de Espectro por Varredura ---")
print(f"Banda Total: {FREQ_START/1e6:.1f} MHz até {FREQ_STOP/1e6:.1f} MHz")
print(f"Largura de Banda por Salto: {STEP_BANDWIDTH/1e6:.1f} MHz")
print(f"Quantidade de saltos necessários por varredura completa: {num_steps}\n")

# =============================================================================
# 3. INICIALIZAÇÃO DO HARDWARE (MODO AUTOLOAD)
# =============================================================================
print("Inicializando o bladeRF...")
try:
    d = bladerf.BladeRF()
    ch = d.Channel(bladerf.CHANNEL_RX(0))
    ch.bandwidth = STEP_BANDWIDTH
    ch.gain = GAIN
    d.set_sample_rate(0, SAMPLE_RATE)
    
    # Configuração de buffer síncrono otimizada para transferências rápidas por salto
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X1,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=8,
        buffer_size=2048,
        num_transfers=4,
        stream_timeout=500
    )
    ch.enable = True
    print("Hardware pronto para varredura de banda larga!")
except Exception as e:
    print(f"\nErro crítico de inicialização: {e}")
    sys.exit(1)

# =============================================================================
# 4. CONFIGURAÇÃO DA GRADE DO GRÁFICO GLOBAL (MOSAICO)
# =============================================================================
# Criar o eixo X unificado para todo o espectro (de 10 MHz a 1700 MHz)
# Estimamos o número de pontos globais multiplicando a resolução básica pelo número de saltos
TOTAL_POINTS = NUM_SAMPLES * num_steps
global_freq_axis = np.linspace(FREQ_START, FREQ_STOP, TOTAL_POINTS)
global_psd = np.full(TOTAL_POINTS, -70.0) # Inicializado com a linha de ruído base

fig, ax = plt.subplots(figsize=(12, 6))
fig.suptitle("Analisador de Espectro de Varredura Larga", fontsize=14, fontweight='bold')

line_spectrum, = ax.plot(global_freq_axis / 1e6, global_psd, color='darkblue', linewidth=1)
ax.set_title("Densidade Espectral de Potência Combinada (Mosaico de Hardware)")
ax.set_xlabel("Frequência (MHz)")
ax_time = ax # Alias para referências internas se necessário
ax.set_ylabel("Potência Relativa (dBFS)")
ax.set_xlim(FREQ_START / 1e6, FREQ_STOP / 1e6)
ax.set_ylim(-70, 10)
ax.grid(True)

plt.tight_layout()
rx_buffer = bytearray(BUFFER_BYTES)

# =============================================================================
# 5. LOOP DE VARREDURA EM TEMPO REAL (ANIMAÇÃO)
# =============================================================================
IQ_SCALE = 2048.0
DISPLAY_REFRESH_INTERVAL = 2


def compute_psd_step(raw_buffer):
    """Extrai IQ, calcula o espectro e retorna um passo de PSD em dBFS."""
    raw_iq = np.frombuffer(raw_buffer, dtype=np.int16).reshape(-1, 2)
    iq_signal = (raw_iq[:, 0].astype(np.float32) + 1j * raw_iq[:, 1].astype(np.float32)) / IQ_SCALE
    fft_data = np.fft.fftshift(np.fft.fft(iq_signal, norm='ortho'))
    power = np.abs(fft_data) ** 2
    return 10.0 * np.log10(np.maximum(power / NUM_SAMPLES, 1e-12))


def update(frame):
    global global_psd

    # Executa uma varredura completa varrendo todos os centros calculados.
    for step_idx, center_f in enumerate(sweep_centers):
        try:
            ch.frequency = int(center_f)
            time.sleep(0.002)
            d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=500)
            psd_step = compute_psd_step(rx_buffer)

            start_idx = step_idx * NUM_SAMPLES
            end_idx = start_idx + NUM_SAMPLES
            global_psd[start_idx:end_idx] = psd_step

        except Exception:
            continue

    line_spectrum.set_ydata(global_psd)

    if frame % DISPLAY_REFRESH_INTERVAL == 0:
        return line_spectrum,

    return line_spectrum,

# Intervalo mais alto para reduzir a pressão da UI sobre o ciclo de varredura.
ani = FuncAnimation(fig, update, interval=30, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nDesligando analisador de varredura larga...")
    try:
        ch.enable = False
    except:
        pass
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

