import bladerf
d = bladerf.BladeRF()
d
d.load_fpga('/home/jorge/Documents/0_PCI_INPE/BDA/Nuand-bladeRF/hostedxA4-latest.rbf')
d
ch = d.Channel(bladerf.CHANNEL_RX(0))
ch
print(ch.frequency)
ch.frequency = 1.405e9
print(ch.frequency)
