import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import sys

# --- CONFIGURAÇÕES DO HARDWARE ---
SAMPLE_RATE = 5000000   
CENTER_FREQ = 1405.000 e6 ##127.925e6 ###1405000000 
BANDWIDTH = 5000000     
GAIN_RX1 = 0           
GAIN_RX2 = 0           

# --- CONFIGURAÇÕES DO BUFFER DUAL-CHANNEL ---
NUM_SAMPLES = 1024 * 16  
BUFFER_BYTES = NUM_SAMPLES * 8

# Histórico para o gráfico de estabilidade de fase (últimos 100 blocos)
HISTORY_LEN = 100
phase_history = np.zeros(HISTORY_LEN)
x_history = np.arange(HISTORY_LEN)

print("Inicializando o bladeRF (Utilizando Autoload do FPGA)...")
try:
    d = bladerf.BladeRF()
    
    ch1 = d.Channel(bladerf.CHANNEL_RX(0))
    ch1.frequency = CENTER_FREQ
    ch1.bandwidth = BANDWIDTH
    ch1.gain = GAIN_RX1
    
    ch2 = d.Channel(bladerf.CHANNEL_RX(1))
    ch2.frequency = CENTER_FREQ
    ch2.bandwidth = BANDWIDTH
    ch2.gain = GAIN_RX2
    
    d.set_sample_rate(0, SAMPLE_RATE)
    d.set_sample_rate(1, SAMPLE_RATE)
    
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X2,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=32,
        buffer_size=8192, 
        num_transfers=16,
        stream_timeout=1000
    )
    
    ch1.enable = True
    ch2.enable = True
    print("Módulos RX1 e RX2 sincronizados com sucesso!")
except Exception as error_init:
    print(f"\nErro crítico de inicialização: {error_init}")
    sys.exit(1)

# --- NOVA INTERFACE GRÁFICA (1 Coluna x 3 Linhas) ---
fig, (ax_ch1, ax_ch2, ax_phase) = plt.subplots(3, 1, figsize=(11, 9))
fig.suptitle("Análise Avançada de Fase e Coerência de Relógio - bladeRF", fontsize=14, fontweight='bold')

time_axis = np.arange(NUM_SAMPLES) / SAMPLE_RATE * 1e3 # milissegundos

# --- Subplot 1: Fase Instantânea Canal 1 ---
line_phase1, = ax_ch1.plot(time_axis, np.zeros(NUM_SAMPLES), marker='.', linestyle='None', markersize=3, label='Fase RX1', color='blue', alpha=0.5)
ax_ch1.set_title("Canal RX1 - Fase Instantânea das Amostras", fontweight='bold')
ax_ch1.set_ylabel("Fase (Graus)")
#ax_ch1.set_ylim(-180,180)
#ax_ch1.grid(True)
ax_ch1.legend(loc='upper right')

# --- Subplot 2: Fase Instantânea Canal 2 ---
line_phase2, = ax_ch2.plot(time_axis, np.zeros(NUM_SAMPLES), marker='.', linestyle='None', markersize=3, label='Fase RX2', color='magenta', alpha=0.5)
ax_ch2.set_title("Canal RX2 - Fase Instantânea das Amostras", fontweight='bold')
ax_ch2.set_ylabel("Fase (Graus)")
#ax_ch2.set_ylim(-180,180)
#ax_ch2.grid(True)
ax_ch2.legend(loc='upper right')

# --- Subplot 3: Histórico da Diferença de Fase Média ---
line_delta, = ax_phase.plot(x_history, phase_history, color='red', linewidth=2, label=r'Diferença Média ($\Delta\phi$)')
ax_phase.set_title(r"Estabilidade Temporal do Delta de Fase Média ($\Delta\phi$)", fontweight='bold')
ax_phase.set_ylabel("Diferença de Fase (Graus)")
ax_phase.set_xlabel("Tempo (Blocos de Captura)")
ax_phase.set_ylim(-180, 180) # Mantido em escala total para flagrar saltos de ambiguidade digitais
ax_phase.set_xlim(0, HISTORY_LEN - 1)
ax_phase.grid(True)
ax_phase.legend(loc='upper right')

# Caixa de texto informativa na janela inferior
txt_stats = ax_phase.text(0.02, 0.08, '', transform=ax_phase.transAxes, fontsize=10, fontweight='bold', 
                          bbox=dict(facecolor='white', alpha=0.85, edgecolor='gray'))

plt.tight_layout()
rx_buffer = bytearray(BUFFER_BYTES)

def update(frame):
    global phase_history
    try:
        d.sync_rx(rx_buffer, NUM_SAMPLES * 2, timeout_ms=1000)
        raw_data = np.frombuffer(rx_buffer, dtype=np.int16)
        
        i1_data = raw_data[0::4]
        q1_data = raw_data[1::4]
        i2_data = raw_data[2::4]
        q2_data = raw_data[3::4]
        
        s1 = (i1_data / 2048.0) + 1j * (q1_data / 2048.0)
        s2 = (i2_data / 2048.0) + 1j * (q2_data / 2048.0)
        
        # Extração das Fases Instantâneas
        inst_phase_ch1 = np.degrees(np.angle(s1))
        inst_phase_ch2 = np.degrees(np.angle(s2))
        
        # Cálculo da Diferença de Fase Média por bloco
        phase_diff_samples = np.angle(s1 * np.conj(s2))
        mean_phase_deg = np.degrees(np.arctan2(np.mean(np.sin(phase_diff_samples)), np.mean(np.cos(phase_diff_samples))))
        
        phase_history = np.roll(phase_history, -1)
        phase_history[-1] = mean_phase_deg
        
        # Atualização dos dados nas curvas
        line_phase1.set_ydata(inst_phase_ch1)
        line_phase2.set_ydata(inst_phase_ch2)
        line_delta.set_ydata(phase_history)
        
        # --- FUNÇÃO DE AJUSTE DINÂMICO E CENTRALIZAÇÃO DO ZOOM (ZOOM AUTOCENTRADO) ---
        # Extrai o centro geométrico da distribuição para evitar distorção perto de +/-180
        center_ch1 = np.degrees(np.arctan2(np.mean(np.sin(np.angle(s1))), np.mean(np.cos(np.angle(s1)))))
        center_ch2 = np.degrees(np.arctan2(np.mean(np.sin(np.angle(s2))), np.mean(np.cos(np.angle(s2)))))
        
        # Aplica uma janela estável de +-45 graus ao redor do ponto médio do ruído
        #ax_ch1.set_ylim(center_ch1 - 45, center_ch1 + 45)
        #ax_ch2.set_ylim(center_ch2 - 45, center_ch2 + 45)
        # Força os limites a ficarem estritamente fixos em todos os frames
        ax_ch1.set_ylim(-180, 180)
        ax_ch2.set_ylim(-180, 180)

        
        # Estatísticas de estabilidade
        phase_std = np.std(phase_history)
        txt_stats.set_text(rf"Delta de Fase Atual: {mean_phase_deg:.2f}°" + "\n" + rf"Desvio Padrão ($\sigma$): {phase_std:.2f}°")
        
    except Exception as e:
        print(f"\nErro no processamento: {e}")
        
    return line_phase1, line_phase2, line_delta, txt_stats

# Ativa o loop dinâmico
ani = FuncAnimation(fig, update, interval=35, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nEncerrando canais de forma segura...")
    try:
        ch1.enable = False
        ch2.enable = False
    except:
        pass
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()




