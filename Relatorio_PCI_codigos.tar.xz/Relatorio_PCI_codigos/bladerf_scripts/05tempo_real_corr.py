import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import sys

# --- CONFIGURAÇÕES DO HARDWARE ---
SAMPLE_RATE = 5000000   # 5 MHz em Hz (Inteiro puro)
CENTER_FREQ = 260.530e6 ####1405000000 # 1405 MHz em Hz
BANDWIDTH = 5000000     # 5 MHz em Hz
GAIN = 40             

# --- CONFIGURAÇÕES DO BUFFER (1 Canal RX1) ---
NUM_SAMPLES = 1024 * 16  # 16k amostras por atualização de tela
BUFFER_BYTES = NUM_SAMPLES * 4 # 4 bytes por amostra (I + Q)

print("Inicializando o bladeRF (Aproveitando o Autoload do FPGA)...")
try:
    # Abertura limpa direta aproveitando o firmware já em cache no kernel
    d = bladerf.BladeRF()
    
    ch = d.Channel(bladerf.CHANNEL_RX(0))
    ch.frequency = CENTER_FREQ
    ch.bandwidth = BANDWIDTH
    ch.gain = GAIN
    
    # CORREÇÃO CRÍTICA: Uso do método explícito estável passando o ID inteiro do canal (0)
    d.set_sample_rate(0, SAMPLE_RATE)
    
    # Configuração estável do Stream síncrono para 1 canal
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X1,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=16,
        buffer_size=4096,
        num_transfers=8,
        stream_timeout=1000
    )
    
    ch.enable = True
    print("Hardware inicializado com sucesso! Abrindo gráficos...")

except Exception as error_init:
    print(f"\nErro crítico ao inicializar o canal RX1: {error_init}")
    print("Certifique-se de ter desconectado e reconectado o cabo USB fisicamente.")
    sys.exit(1)

# 2. Configuração da Interface Gráfica (Matplotlib)
fig, (ax_time, ax_freq) = plt.subplots(2, 1, figsize=(11, 7))
fig.suptitle("Monitoramento em Tempo Real (1 Canal) - bladeRF", fontsize=14, fontweight='bold')

# Vetores de eixos X calibrados para o gráfico
time_axis = np.arange(NUM_SAMPLES) / SAMPLE_RATE * 1e3 
freq_axis = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1/SAMPLE_RATE)) + CENTER_FREQ

line_i, = ax_time.plot(time_axis, np.zeros(NUM_SAMPLES), label='I (Em Fase)', color='blue', alpha=0.7)
line_q, = ax_time.plot(time_axis, np.zeros(NUM_SAMPLES), label='Q (Quadratura)', color='orange', alpha=0.7)
line_spec, = ax_freq.plot(freq_axis / 1e6, np.zeros(NUM_SAMPLES), color='purple')

# Estilização do gráfico do Tempo
ax_time.set_title("Domínio do Tempo")
ax_time.set_xlabel("Tempo (ms)")
ax_time.set_ylabel("Amplitude Linear (Int16)")
ax_time.set_ylim(-2048, 2048) 
ax_time.grid(True)
ax_time.legend(loc='upper right')

# Caixa de texto informativa para a Potência Total (Corrigida com r"")
txt_power = ax_time.text(0.02, 0.82, '', transform=ax_time.transAxes, 
                         fontsize=11, fontweight='bold', color='darkred',
                         bbox=dict(facecolor='white', alpha=0.85, edgecolor='gray'))

# Estilização do gráfico de Frequência
ax_freq.set_title("Domínio da Frequência (Espectro)")
ax_freq.set_xlabel("Frequência (MHz)")
ax_freq.set_ylabel("Potência Relativa (dB)")
ax_freq.set_ylim(-60, 40)
ax_freq.grid(True)

plt.tight_layout()

# Alocação do buffer persistente
rx_buffer = bytearray(BUFFER_BYTES)

# 3. Função de Atualização de Tela em Tempo Real
def update(frame):
    try:
        # Pede exatamente o bloco nominal para preencher o gráfico de 1 canal de ponta a ponta
        d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=1000)
        
        raw_data = np.frombuffer(rx_buffer, dtype=np.int16)
        i_data = raw_data[0::2]
        q_data = raw_data[1::2]
        
        # Normalização de escala Q11
        i_norm = i_data / 2048.0
        q_norm = q_data / 2048.0
        
        # Cálculo da potência total média (I^2 + Q^2)
        total_power_linear = np.mean(i_norm**2 + q_norm**2)
        total_power_db = 10 * np.log10(total_power_linear + 1e-12)
        
        # Atualização dos eixos
        line_i.set_ydata(i_data)
        line_q.set_ydata(q_data)
        
        iq_signal = i_norm + 1j * q_norm
        fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
        psd = 10 * np.log10((np.abs(fft_data)**2) / NUM_SAMPLES + 1e-12)
        line_spec.set_ydata(psd)
        
        # Atualização da caixa de texto
        txt_power.set_text(f"Potência Total: {total_power_db:.2f} dBFS\nLinear ($I^2 + Q^2$): {total_power_linear:.4f}")
        ax_time.set_title("Domínio do Tempo (Janela Instantânea)")
        
    except Exception as e:
        print(f"\nErro de amostragem no frame: {e}")
        
    return line_i, line_q, line_spec, txt_power

# Dispara a renderização do loop animado
ani = FuncAnimation(fig, update, interval=30, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nDesligando canal RX de forma segura...")
    try:
        ch.enable = False
    except:
        pass
    print("Programa encerrado.")
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

