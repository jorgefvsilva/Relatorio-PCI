import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import sys

# --- CONFIGURAÇÕES DO HARDWARE ---
SAMPLE_RATE = 5000000   # 5 MHz em Hz
CENTER_FREQ = 1405000000 # 1405 MHz em Hz
BANDWIDTH = 5000000     # 5 MHz em Hz
GAIN_RX1 = 40           # Ganho do Canal 1 em dB
GAIN_RX2 = 40           # Ganho do Canal 2 em dB

# --- CONFIGURAÇÕES DO BUFFER PARA 2 CANAIS ---
NUM_SAMPLES = 1024 * 16  # 16k amostras por canal
# Cada amostra de 2 canais possui 4 inteiros (I1, Q1, I2, Q2) = 8 bytes por par de amostras
BUFFER_BYTES = NUM_SAMPLES * 8

print("Inicializando o bladeRF (Aproveitando o Autoload do FPGA)...")
try:
    # Abertura direta e limpa sem travar a calibração do AD9361
    d = bladerf.BladeRF()
    
    # Configuração do Canal RX1 (ID 0)
    ch1 = d.Channel(bladerf.CHANNEL_RX(0))
    ch1.frequency = CENTER_FREQ
    ch1.bandwidth = BANDWIDTH
    ch1.gain = GAIN_RX1
    
    # Configuração do Canal RX2 (ID 1)
    ch2 = d.Channel(bladerf.CHANNEL_RX(1))
    ch2.frequency = CENTER_FREQ
    ch2.bandwidth = BANDWIDTH
    ch2.gain = GAIN_RX2
    
    # Define a taxa de amostragem em ambos os canais (IDs 0 e 1)
    d.set_sample_rate(0, SAMPLE_RATE)
    d.set_sample_rate(1, SAMPLE_RATE)
    
    # Configuração do Stream Múltiplo (Layout RX_X2 para amostragem síncrona de 2 canais)
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X2,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=32,
        buffer_size=8192, 
        num_transfers=16,
        stream_timeout=1000
    )
    
    # Habilita fisicamente a recepção em ambas as portas RF
    ch1.enable = True
    ch2.enable = True
    print("Módulos RX1 e RX2 inicializados com sucesso! Abrindo matriz de 4 gráficos...")

except Exception as error_init:
    print(f"\nErro crítico ao inicializar os dois canais: {error_init}")
    print("Certifique-se de ter desconectado e reconectado o cabo USB fisicamente.")
    sys.exit(1)

# 3. Configuração da Interface Gráfica (Matriz 2x2 de Subgráficos)
fig, axs = plt.subplots(2, 2, figsize=(14, 8))
fig.suptitle("Monitoramento Dual-Channel em Tempo Real - bladeRF 2.0 Micro", fontsize=14, fontweight='bold')

# Mapeamento das posições dos eixos
ax_time_ch1 = axs[0, 0]
ax_freq_ch1 = axs[0, 1]
ax_time_ch2 = axs[1, 0]
ax_freq_ch2 = axs[1, 1]

time_axis = np.arange(NUM_SAMPLES) / SAMPLE_RATE * 1e3 # milissegundos
freq_axis = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1/SAMPLE_RATE)) + CENTER_FREQ

# --- Inicialização das Curvas do Canal 1 ---
line_i1, = ax_time_ch1.plot(time_axis, np.zeros(NUM_SAMPLES), label='I1 (Em Fase)', color='blue', alpha=0.7)
line_q1, = ax_time_ch1.plot(time_axis, np.zeros(NUM_SAMPLES), label='Q1 (Quadratura)', color='orange', alpha=0.7)
line_spec1, = ax_freq_ch1.plot(freq_axis / 1e6, np.zeros(NUM_SAMPLES), color='purple')

# --- Inicialização das Curvas do Canal 2 ---
line_i2, = ax_time_ch2.plot(time_axis, np.zeros(NUM_SAMPLES), label='I2 (Em Fase)', color='cyan', alpha=0.7)
line_q2, = ax_time_ch2.plot(time_axis, np.zeros(NUM_SAMPLES), label='Q2 (Quadratura)', color='magenta', alpha=0.7)
line_spec2, = ax_freq_ch2.plot(freq_axis / 1e6, np.zeros(NUM_SAMPLES), color='forestgreen')

# --- Estilização Padrão dos Eixos do Tempo (Coluna Esquerda) ---
for ax, title in [(ax_time_ch1, "Canal RX1 - Domínio do Tempo"), (ax_time_ch2, "Canal RX2 - Domínio do Tempo")]:
    ax.set_title(title, fontweight='bold', fontsize=11)
    ax.set_xlabel("Tempo (ms)")
    ax.set_ylabel("Amplitude Linear (Int16)")
    ax.set_ylim(-2048, 2048)
    ax.grid(True)
    ax.legend(loc='upper right')

# Caixas de Texto Persistentes para indicação de potência nos canais (Corrigido com r"")
txt_power_ch1 = ax_time_ch1.text(0.02, 0.78, '', transform=ax_time_ch1.transAxes, fontsize=10, 
                                 fontweight='bold', color='darkred', bbox=dict(facecolor='white', alpha=0.85, edgecolor='gray'))
txt_power_ch2 = ax_time_ch2.text(0.02, 0.78, '', transform=ax_time_ch2.transAxes, fontsize=10, 
                                 fontweight='bold', color='darkgreen', bbox=dict(facecolor='white', alpha=0.85, edgecolor='gray'))

# --- Estilização Padrão dos Eixos da Frequência (Coluna Direita) ---
for ax, title in [(ax_freq_ch1, "Canal RX1 - Espectro (PSD)"), (ax_freq_ch2, "Canal RX2 - Espectro (PSD)")] :
    ax.set_title(title, fontweight='bold', fontsize=11)
    ax.set_xlabel("Frequência (MHz)")
    ax.set_ylabel("Potência Relativa (dB)")
    ax.set_ylim(-60, 40)
    ax.grid(True)

plt.tight_layout()

# Alocação estática do buffer intercalado
rx_buffer = bytearray(BUFFER_BYTES)

# 4. Função de Aktualização de Tela (Com correção NUM_SAMPLES * 2 para preencher o eixo X completo)
def update(frame):
    try:
        # Captura o bloco sínclito contendo amostras de ambas as antenas
        d.sync_rx(rx_buffer, NUM_SAMPLES * 2, timeout_ms=1000)
        
        raw_data = np.frombuffer(rx_buffer, dtype=np.int16)
        
        # Desentrelaçamento das componentes usando stride 4
        i1_data = raw_data[0::4]
        q1_data = raw_data[1::4]
        i2_data = raw_data[2::4]
        q2_data = raw_data[3::4]
        
        # Normalização de amplitude individual (Escala Q11)
        i1_norm, q1_norm = i1_data / 2048.0, q1_data / 2048.0
        i2_norm, q2_norm = i2_data / 2048.0, q2_data / 2048.0
        
        # --- CÁLCULO DE POTÊNCIA TOTAL MÉDIA (I^2 + Q^2) ---
        power_linear_ch1 = np.mean(i1_norm**2 + q1_norm**2)
        power_db_ch1 = 10 * np.log10(power_linear_ch1 + 1e-12)
        
        power_linear_ch2 = np.mean(i2_norm**2 + q2_norm**2)
        power_db_ch2 = 10 * np.log10(power_linear_ch2 + 1e-12)
        
        # --- ATUALIZAÇÃO DOS GRÁFICOS DO CANAL 1 ---
        line_i1.set_ydata(i1_data)
        line_q1.set_ydata(q1_data)
        
        iq_signal_ch1 = i1_norm + 1j * q1_norm
        fft_ch1 = np.fft.fftshift(np.fft.fft(iq_signal_ch1))
        psd_ch1 = 10 * np.log10((np.abs(fft_ch1)**2) / NUM_SAMPLES + 1e-12)
        line_spec1.set_ydata(psd_ch1)
        
        txt_power_ch1.set_text(f"Potência Total: {power_db_ch1:.2f} dBFS\nLinear: {power_linear_ch1:.4f}")
        
        # --- ATUALIZAÇÃO DOS GRÁFICOS DO CANAL 2 ---
        line_i2.set_ydata(i2_data)
        line_q2.set_ydata(q2_data)
        
        iq_signal_ch2 = i2_norm + 1j * q2_norm
        fft_ch2 = np.fft.fftshift(np.fft.fft(iq_signal_ch2))
        psd_ch2 = 10 * np.log10((np.abs(fft_ch2)**2) / NUM_SAMPLES + 1e-12)
        line_spec2.set_ydata(psd_ch2)
        
        txt_power_ch2.set_text(f"Potência Total: {power_db_ch2:.2f} dBFS\nLinear: {power_linear_ch2:.4f}")
        
    except Exception as e:
        print(f"\nErro de amostragem dual-channel no frame: {e}")
        
    return line_i1, line_q1, line_spec1, line_i2, line_q2, line_spec2, txt_power_ch1, txt_power_ch2

# Dispara o loop de animação
ani = FuncAnimation(fig, update, interval=35, blit=False, cache_frame_data=False)

# Fechamento Limpo de Hardware
def on_close(event):
    print("\nDesligando canais RX1 e RX2 de forma segura...")
    try:
        ch1.enable = False
        ch2.enable = False
    except:
        pass
    print("Receptor encerrado.")
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

