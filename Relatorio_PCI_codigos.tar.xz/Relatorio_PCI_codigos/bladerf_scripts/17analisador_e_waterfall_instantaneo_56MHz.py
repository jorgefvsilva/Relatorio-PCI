import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import sys

# =============================================================================
# 1. SELEÇÃO DA FREQUÊNCIA (MODO START_STOP OU CENTER)
# =============================================================================
MODO_ENTRADA = "CENTER" # "START_STOP"  # Opções: "CENTER" ou "START_STOP"

# Largura de banda instantânea máxima permitida pelo chip AD9361 do bladeRF
SPAN_FIXO = 56000000  # 56 MHz de largura total de análise

if MODO_ENTRADA == "CENTER":
    #Limite inferior 70 MHz
    CENTER_FREQ = 129_530_500 #260_530_000 #1405000000  # 1405 MHz 
    FREQ_START = CENTER_FREQ - (SPAN_FIXO / 2)
    FREQ_STOP  = CENTER_FREQ + (SPAN_FIXO / 2)

elif MODO_ENTRADA == "START_STOP":
    FREQ_START = 1377000000   # 1377 MHz (Início)
    FREQ_STOP  = 1433000000   # 1433 MHz (Fim)
    
    # Calcula o centro real baseado nas suas coordenadas de interesse
    CENTER_FREQ = int((FREQ_START + FREQ_STOP) / 2)
    # Reajusta as bordas exatas para cravar os 56 MHz simétricos ao redor do centro
    FREQ_START = CENTER_FREQ - (SPAN_FIXO / 2)
    FREQ_STOP  = CENTER_FREQ + (SPAN_FIXO / 2)

# Parâmetros físicos do hardware baseados no SPAN máximo
SAMPLE_RATE = SPAN_FIXO  # 56 Msps
BANDWIDTH   = SPAN_FIXO  # Filtro analógico interno totalmente aberto em 56 MHz
GAIN = 42                # Ganho em dB

# --- Configurações do Waterfall ---
NUM_SAMPLES = 1024 * 4   # 4k pontos de FFT para ter ótima resolução visual na tela
BUFFER_BYTES = NUM_SAMPLES * 4
WATERFALL_LINES = 100    # Quantidade de linhas históricas na cascata

print(f"--- Analisador de Espectro Instantâneo + Waterfall (56 MHz) ---")
print(f"Frequência Inicial (Start): {FREQ_START / 1e6:.2f} MHz")
print(f"Frequência Central (Center): {CENTER_FREQ / 1e6:.2f} MHz")
print(f"Frequência Final (Stop): {FREQ_STOP / 1e6:.2f} MHz")
print(f"Span de Frequência Instantâneo: {SPAN_FIXO / 1e6:.2f} MHz\n")

# =============================================================================
# 2. INICIALIZAÇÃO DO HARDWARE (MODO AUTOLOAD)
# =============================================================================
print("Conectando ao bladeRF...")
try:
    d = bladerf.BladeRF()
    ch = d.Channel(bladerf.CHANNEL_RX(0))
    
    # Força o chip no modo Manual e desativa o AGC de fábrica
    ch.gain_mode = bladerf._bladerf.GainMode.Manual
    
    ch.frequency = CENTER_FREQ
    ch.bandwidth = BANDWIDTH
    ch.gain = GAIN            
    
    d.set_sample_rate(0, SAMPLE_RATE)
    
    # Configuração de Stream contínuo ultrarrápido para suportar 56 Msps sem perdas
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X1,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=32,       # Vazão para 56 MSps
        buffer_size=8192,     # Eficiência de DMA via USB 3.0
        num_transfers=16,
        stream_timeout=1000
    )
    ch.enable = True
    print("Captura iniciada! Abrindo interface gráfica...")
except Exception as e:
    print(f"\nErro crítico de hardware: {e}")
    sys.exit(1)

# =============================================================================
# 3. CONFIGURAÇÃO DA INTERFACE GRÁFICA (ESPECTRO + WATERFALL)
# =============================================================================
fig, (ax_spec, ax_water) = plt.subplots(2, 1, figsize=(11, 8), gridspec_kw={'height_ratios': [1, 1.5]})
fig.suptitle("Analisador Instantâneo e Espectrograma de 56 MHz - bladeRF", fontsize=14, fontweight='bold')

# Criação do eixo X calibrado em MHz
freq_axis = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1/SAMPLE_RATE)) + CENTER_FREQ
freq_axis_mhz = freq_axis / 1e6

# Matriz inicializada com o ruído base para o Waterfall
waterfall_matrix = np.full((WATERFALL_LINES, NUM_SAMPLES), -65.0)

# --- Subplot 1: Espectro de Potência Instantâneo ---
line_spectrum, = ax_spec.plot(freq_axis_mhz, np.full(NUM_SAMPLES, -70.0), color='royalblue', linewidth=1.2)
ax_spec.set_title(f"Visualização em Tempo Real (Center: {CENTER_FREQ/1e6:.2f} MHz)")
ax_spec.set_ylabel("Potência Relativa (dBFS)")
ax_spec.set_xlim(FREQ_START / 1e6, FREQ_STOP / 1e6)
ax_spec.set_ylim(-70, 10)  # Travado na escala dBFS real
ax_spec.grid(True)

# --- Subplot 2: Imagem 2D para o Waterfall (Cascata) ---
# O colormap 'jet' mapeia a amplitude em dBFS para cores (Azul=Ruído de base, Vermelho=Sinal Forte)
# vmin e vmax limitam as cores para casar com a dinâmica real do ruído analógico
im_water = ax_water.imshow(waterfall_matrix, aspect='auto', cmap='jet', vmin=-65, vmax=5,
                            extent=[FREQ_START / 1e6, FREQ_STOP / 1e6, WATERFALL_LINES, 0])
ax_water.set_title("Histórico Temporal (Waterfall)")
ax_water.set_xlabel("Frequência (MHz)")
ax_water.set_ylabel("Linhas de Varredura (Tempo)")

plt.tight_layout()
rx_buffer = bytearray(BUFFER_BYTES)

# =============================================================================
# 4. LOOP DE ATUALIZAÇÃO SÍNCRONA DE ALTA VELOCIDADE
# =============================================================================
def update(frame):
    global waterfall_matrix
    try:
        # Captura direta do fluxo contínuo de 56 MHz sem interrupções de hardware
        d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=1000)
        raw_data = np.frombuffer(rx_buffer, dtype=np.int16)
        
        # Conversão complexa normalizada
        iq_signal = (raw_data[0::2] + 1j * raw_data[1::2]) / 2048.0
        
        # Processamento matemático do Espectro (FFT)
        fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
        psd = 10 * np.log10((np.abs(fft_data)**2) / NUM_SAMPLES + 1e-12)
        
        # Atualiza o gráfico de linha superior
        line_spectrum.set_ydata(psd)
        
        # Atualiza a matriz do Waterfall (Desloca as linhas antigas para baixo e insere a nova no topo)
        waterfall_matrix = np.roll(waterfall_matrix, 1, axis=0)
        waterfall_matrix[0, :] = psd
        
        # Atualiza os dados da imagem 2D na tela
        im_water.set_array(waterfall_matrix)
        
    except Exception as e:
        print(f"\nErro de processamento no bloco: {e}")
        
    return line_spectrum, im_water

# Intervalo em 1ms para forçar a renderização na velocidade máxima que a CPU/GPU aguentar
ani = FuncAnimation(fig, update, interval=1, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nDesligando analisador e cascata instantânea...")
    try:
        ch.enable = False
    except:
        pass
    print("Programa finalizado de forma segura.")
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

