import numpy as np
import matplotlib.pyplot as plt

# --- CONFIGURAÇÕES DA CAPTURA ---
file_path = "captura_1405MHz.iq"
sample_rate = 5.0e6  # 5 MHz
center_freq = 1405.0e6  # 1405 MHz

# --- CONFIGURAÇÕES DE VISUALIZAÇÃO ---
# Para não travar a memória, escolhemos quantas amostras ler e a partir de onde
num_samples_to_plot = 1024 * 16  # Tamanho do bloco para o gráfico (ex: 16k amostras)
#offset_samples = 0  # 0 significa ler desde o início do arquivo
offset_samples = 1024*16*32

# 1. Calcular a posição em bytes (Cada amostra I/Q int16 ocupa 4 bytes)
bytes_per_sample = 4
offset_bytes = offset_offset = offset_samples * bytes_per_sample
count_ints = num_samples_to_plot * 2  # 2 inteiros (I e Q) por amostra

# 2. Ler o bloco de dados do arquivo binário
try:
    with open(file_path, "rb") as f:
        f.seek(offset_bytes)
        # Lê os dados diretamente como inteiros de 16 bits (int16)
        raw_data = np.fromfile(f, dtype=np.int16, count=count_ints)

    if len(raw_data) == 0:
        print("Erro: O arquivo está vazio ou o offset é maior que o arquivo.")
        exit()

    # 3. Reconstruir o sinal complexo (I + jQ) e normalizar
    # Amostras I estão nos índices pares, Q nos ímpares
    i_data = raw_data[0::2]
    q_data = raw_data[1::2]
    
    # Ajusta o tamanho caso o arquivo tenha terminado antes do esperado
    min_len = min(len(i_data), len(q_data))
    iq_signal = (i_data[:min_len] + 1j * q_data[:min_len]) / 2048.0

    # 4. Criar os vetores de tempo e frequência para os eixos do gráfico
    time_axis = np.arange(len(iq_signal)) / sample_rate
    # Cria o eixo de frequências deslocado para a frequência central real (1405 MHz)
    freq_axis = np.fft.fftshift(np.fft.fftfreq(len(iq_signal), 1/sample_rate)) + center_freq

    # 5. Plotar os Gráficos
    plt.figure(figsize=(12, 8))

    # Gráfico 1: Domínio do Tempo (Forma de Onda)
    plt.subplot(2, 1, 1)
    plt.plot(time_axis * 1e3, i_data[:min_len], label='I (Em Fase)', color='blue', alpha=0.7)
    plt.plot(time_axis * 1e3, q_data[:min_len], label='Q (Quadratura)', color='orange', alpha=0.7)
    plt.title("Sinal no Domínio do Tempo (Formato de Onda Bruto)")
    plt.xlabel("Tempo (milissegundos)")
    plt.ylabel("Amplitude Linear (Amostras Int16)")
    plt.grid(True)
    plt.legend()

    # Gráfico 2: Domínio da Frequência (Espectro de Potência)
    plt.subplot(2, 1, 2)
    # Calcula a FFT e converte para escala Logarítmica (dB)
    fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
    psd = 10 * np.log10(np.abs(fft_data)**2 / len(iq_signal))
    
    plt.plot(freq_axis / 1e6, psd, color='purple')
    plt.title("Espectro de Frequência (PSD)")
    plt.xlabel("Frequência (MHz)")
    plt.ylabel("Potência Relativa (dB)")
    plt.grid(True)

    plt.tight_layout()
    plt.show()

except FileNotFoundError:
    print(f"Erro: O arquivo '{file_path}' não foi encontrado no diretório atual.")

