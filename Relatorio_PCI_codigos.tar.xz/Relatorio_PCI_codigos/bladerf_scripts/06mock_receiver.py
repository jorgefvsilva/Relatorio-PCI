import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import os
import sys

# --- CONFIGURAÇÕES DA SIMULAÇÃO ---
FILE_PATH = "captura_1405MHz.iq"
SAMPLE_RATE = 5.0e6   
CENTER_FREQ = 1405.0e6 
NUM_SAMPLES = 1024 * 16  

INTS_PER_BLOCK = NUM_SAMPLES * 2
BYTES_PER_BLOCK = INTS_PER_BLOCK * 2  

if not os.path.exists(FILE_PATH):
    print(f"Erro: O arquivo '{FILE_PATH}' não foi encontrado.")
    sys.exit(1)

print(f"Modo Mock Iniciado. Lendo dados de: {FILE_PATH}")
file_stream = open(FILE_PATH, "rb")

# Configuração da Interface Gráfica
fig, (ax_time, ax_freq) = plt.subplots(2, 1, figsize=(11, 7))
fig.suptitle("Monitoramento em Tempo Real - MOCK (Arquivo .iq)", fontsize=14, fontweight='bold')

time_axis = np.arange(NUM_SAMPLES) / SAMPLE_RATE * 1e3 
freq_axis = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1/SAMPLE_RATE)) + CENTER_FREQ

line_i, = ax_time.plot(time_axis, np.zeros(NUM_SAMPLES), label='I (Em Fase)', color='blue', alpha=0.7)
line_q, = ax_time.plot(time_axis, np.zeros(NUM_SAMPLES), label='Q (Quadratura)', color='orange', alpha=0.7)
line_spec, = ax_freq.plot(freq_axis / 1e6, np.zeros(NUM_SAMPLES), color='purple')

ax_time.set_title("Domínio do Tempo")
ax_time.set_xlabel("Tempo (ms)")
ax_time.set_ylabel("Amplitude Linear (Int16)")
ax_time.set_ylim(-2048, 2048) 
ax_time.grid(True)
ax_time.legend(loc='upper right')

# Caixa de texto persistente para a Potência Total
txt_power = ax_time.text(0.02, 0.82, '', transform=ax_time.transAxes, 
                         fontsize=11, fontweight='bold', color='darkred',
                         bbox=dict(facecolor='white', alpha=0.85, edgecolor='gray'))

ax_freq.set_title("Domínio da Frequência (Espectro)")
ax_freq.set_xlabel("Frequência (MHz)")
ax_freq.set_ylabel("Potência Relativa (dB)")
ax_freq.set_ylim(-60, 40)
ax_freq.grid(True)

plt.tight_layout()

def update(frame):
    try:
        raw_bytes = file_stream.read(BYTES_PER_BLOCK)
        
        if len(raw_bytes) < BYTES_PER_BLOCK:
            file_stream.seek(0)
            raw_bytes = file_stream.read(BYTES_PER_BLOCK)
            
        raw_data = np.frombuffer(raw_bytes, dtype=np.int16)
        i_data = raw_data[0::2]
        q_data = raw_data[1::2]
        
        min_len = min(len(i_data), len(q_data))
        i_data = i_data[:min_len]
        q_data = q_data[:min_len]
        
        iq_signal = (i_data + 1j * q_data) / 2048.0
        
        # Cálculo de Potência Total
        total_power_linear = np.mean(np.abs(iq_signal)**2)
        total_power_db = 10 * np.log10(total_power_linear + 1e-12)
        
        # Atualização das curvas
        line_i.set_ydata(i_data)
        line_q.set_ydata(q_data)
        
        fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
        psd = 10 * np.log10((np.abs(fft_data)**2) / NUM_SAMPLES + 1e-12)
        line_spec.set_ydata(psd)
        
        # Atualização do texto de potência na tela
        txt_power.set_text(f"Potência Total: {total_power_db:.2f} dBFS\nLinear: {total_power_linear:.4f}")
        
    except Exception as e:
        print(f"\nErro ao processar bloco: {e}")
        
    return line_i, line_q, line_spec, txt_power

ani = FuncAnimation(fig, update, interval=30, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nFechando gráficos.")
    file_stream.close()
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()



