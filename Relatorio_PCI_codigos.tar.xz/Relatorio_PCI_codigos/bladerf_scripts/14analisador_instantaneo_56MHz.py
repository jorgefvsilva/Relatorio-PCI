import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import sys

# =============================================================================
# 1. MODO DE CONFIGURAÇÃO DA BANDA (ESCOLHA UMA DAS OPÇÕES)
# =============================================================================
#MODO_ENTRADA = "START_STOP"  # Opções: "CENTER" ou "START_STOP"
MODO_ENTRADA = "CENTER"

# Largura de banda instantânea máxima permitida pelo chip AD9361 do bladeRF
SPAN_FIXO = 56000000  # 56 MHz de largura total de análise

if MODO_ENTRADA == "CENTER":
    # Opção A: Você define o centro e o script calcula as bordas
    #CENTER_FREQ = 1405000000  # 1405 MHz
    CENTER_FREQ =  540_000_000
    FREQ_START = CENTER_FREQ - (SPAN_FIXO / 2)
    FREQ_STOP  = CENTER_FREQ + (SPAN_FIXO / 2)

elif MODO_ENTRADA == "START_STOP":
    # Opção B: Você define as bordas e o script calcula o centro ideal
    # NOTA: Como o SPAN é fixo em 56 MHz, a distância entre STOP e START deve ser 56 MHz
    FREQ_START = 1377000000   # 1377 MHz (Início)
    FREQ_STOP  = 1433000000   # 1433 MHz (Fim)
    
    # Recalcula o centro real baseado nas suas coordenadas de interesse
    CENTER_FREQ = int((FREQ_START + FREQ_STOP) / 2)
    # Reajusta as bordas exatas para cravar os 56 MHz simétricos ao redor do centro
    FREQ_START = CENTER_FREQ - (SPAN_FIXO / 2)
    FREQ_STOP  = CENTER_FREQ + (SPAN_FIXO / 2)

# Configurações de amostragem do hardware baseadas no SPAN máximo
SAMPLE_RATE = SPAN_FIXO  # 56 Msps (Amostragem em quadratura cobre 56 MHz de banda)
BANDWIDTH   = SPAN_FIXO  # Filtro analógico interno totalmente aberto em 56 MHz

# Configurações de Resolução Gráfica
NUM_SAMPLES = 1024 * 4   # 4k pontos de FFT para ter ótima resolução visual na tela
BUFFER_BYTES = NUM_SAMPLES * 4
GAIN = 0 #35                # Ganho em dB

print(f"--- Analisador de Espectro Instantâneo (Banda Máxima) ---")
print(f"Modo de Inicialização: {MODO_ENTRADA}")
print(f"Frequência Inicial (Start): {FREQ_START / 1e6:.2f} MHz")
print(f"Frequência Central (Center): {CENTER_FREQ / 1e6:.2f} MHz")
print(f"Frequência Final (Stop): {FREQ_STOP / 1e6:.2f} MHz")
print(f"Span de Frequência Instantâneo: {SPAN_FIXO / 1e6:.2f} MHz (Fixo)\n")

# =============================================================================
# 2. INICIALIZAÇÃO DO HARDWARE (MODO AUTOLOAD)
# =============================================================================
print("Conectando ao bladeRF...")
try:
    d = bladerf.BladeRF()
    ch = d.Channel(bladerf.CHANNEL_RX(0))
    ch.frequency = CENTER_FREQ
    ch.bandwidth = BANDWIDTH
    ch.gain = GAIN
    d.set_sample_rate(0, SAMPLE_RATE)
    
    # Configuração de Stream contínuo ultrarrápido para suportar 56 Msps sem perdas
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X1,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=32,       # Aumentado para dar vazão à taxa de 56 MSps
        buffer_size=8192,     # Pacotes USB maiores para máxima eficiência de DMA
        num_transfers=16,
        stream_timeout=1000
    )
    ch.enable = True
    print("Captura iniciada! Abrindo tela do analisador...")
except Exception as e:
    print(f"\nErro crítico de hardware: {e}")
    sys.exit(1)

# =============================================================================
# 3. CONFIGURAÇÃO DA INTERFACE GRÁFICA DO ANALISADOR
# =============================================================================
fig, ax = plt.subplots(figsize=(12, 6))
fig.suptitle("Analisador de Espectro Instantâneo - 56 MHz de Banda", fontsize=14, fontweight='bold')

# Criação do eixo X calibrado em MHz variando de START até STOP
freq_axis = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1/SAMPLE_RATE)) + CENTER_FREQ
freq_axis_mhz = freq_axis / 1e6

line_spectrum, = ax.plot(freq_axis_mhz, np.full(NUM_SAMPLES, -70.0), color='royalblue', linewidth=1.2)
ax.set_title(f"Visualização em Tempo Real (Center: {CENTER_FREQ/1e6:.2f} MHz | Span: 56 MHz)")
ax.set_xlabel("Frequência (MHz)")
ax.set_ylabel("Potência Relativa (dBFS)")
ax.set_xlim(FREQ_START / 1e6, FREQ_STOP / 1e6)
ax.set_ylim(-70, 10)
ax.grid(True)

plt.tight_layout()
rx_buffer = bytearray(BUFFER_BYTES)

# =============================================================================
# 4. LOOP DE ATUALIZAÇÃO SÍNCRONA (MÁXIMA VELOCIDADE)
# =============================================================================
def update(frame):
    try:
        # Captura direta do fluxo contínuo de 56 MHz sem interrupções de hardware
        d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=1000)
        raw_data = np.frombuffer(rx_buffer, dtype=np.int16)
        
        # Conversão complexa normalizada
        iq_signal = (raw_data[0::2] + 1j * raw_data[1::2]) / 2048.0
        
        # Processamento matemático do Espectro (FFT)
        fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
        psd = 10 * np.log10((np.abs(fft_data)**2) / NUM_SAMPLES + 1e-12)
        
        # Atualiza a linha do gráfico instantaneamente
        line_spectrum.set_ydata(psd)
        
    except Exception as e:
        print(f"\nErro de processamento no bloco: {e}")
        
    return line_spectrum,

# Intervalo em 1ms para forçar o Matplotlib a renderizar na velocidade máxima que a CPU aguentar
ani = FuncAnimation(fig, update, interval=1, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nDesligando analisador de espectro instantâneo...")
    try:
        ch.enable = False
    except:
        pass
    print("Programa finalizado.")
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

