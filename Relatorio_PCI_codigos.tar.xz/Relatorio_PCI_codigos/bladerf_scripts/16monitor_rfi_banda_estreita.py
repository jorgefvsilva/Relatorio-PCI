import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from scipy.signal import iirnotch, lfilter
import sys

# =============================================================================
# 1. PARÂMETROS CONFIGURÁVEIS DE RFI E HARDWARE
# =============================================================================
SAMPLE_RATE = 5000000    # 5 MHz (Este é o SPAN total do espectro)
CENTER_FREQ = 260_000_000 #1405000000  # 1405 MHz (Frequência Central)
BANDWIDTH = 5000000      # Filtro analógico interno de 5 MHz
GAIN = 0                # Ganho RX em dB

# --- Configuração do Filtro Rejeita-Banda (Notch Filter Digital) ---
# Funciona apenas com frequencias acima da frequencia central seleccionada!!!
APLICAR_FILTRO_NOTCH = True ##True
FREQ_INTERFERENCIA = 260_000_000  # Exemplo: Frequência que queremos rejeitar (1406.5 MHz)
LARGURA_REJEICAO_HZ = 250000    # Largura de banda do corte (50 kHz)

# --- Configurações do Waterfall ---
NUM_SAMPLES = 1024 * 4   # 4k pontos de FFT (Boa resolução de frequência para RFI)
BUFFER_BYTES = NUM_SAMPLES * 4
WATERFALL_LINES = 100    # Quantidade de linhas históricas na cascata

# Calcular frequências limites (Start / Stop) para exibição e conferência
FREQ_START = CENTER_FREQ - (SAMPLE_RATE / 2)
FREQ_STOP = CENTER_FREQ + (SAMPLE_RATE / 2)

print(f"--- Configuração do Monitor de RFI ---")
print(f"Frequência Inicial (Start): {FREQ_START / 1e6:.2f} MHz")
print(f"Frequência Central (Center): {CENTER_FREQ / 1e6:.2f} MHz")
print(f"Frequência Final (Stop): {FREQ_STOP / 1e6:.2f} MHz")
print(f"Span Total Monitorado: {SAMPLE_RATE / 1e6:.2f} MHz\n")

# =============================================================================
# 2. INICIALIZAÇÃO DO BLADERF (MODO AUTOLOAD)
# =============================================================================
print("Inicializando o bladeRF...")
try:
    d = bladerf.BladeRF()
    ch = d.Channel(bladerf.CHANNEL_RX(0))
    ch.frequency = CENTER_FREQ
    ch.bandwidth = BANDWIDTH
    ch.gain = GAIN
    d.set_sample_rate(0, SAMPLE_RATE)
    
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X1,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=16,
        buffer_size=4096,
        num_transfers=8,
        stream_timeout=1000
    )
    ch.enable = True
    print("Hardware pronto e recebendo dados!")
except Exception as e:
    print(f"\nErro crítico de hardware: {e}")
    sys.exit(1)

# =============================================================================
# 3. PROJETAR FILTRO DIGITAL REJEITA-BANDA
# =============================================================================
if APLICAR_FILTRO_NOTCH:
    # Converter a frequência absoluta alvo em frequência normalizada (0.0 a 1.0 onde 1.0 é Nyquist)
    freq_relativa_target = FREQ_INTERFERENCIA - CENTER_FREQ
    
    # Validação para garantir que o alvo está dentro do Span amostrado
    if abs(freq_relativa_target) < (SAMPLE_RATE / 2):
        w0 = freq_relativa_target / (SAMPLE_RATE / 2)
        # Fator de qualidade Q do filtro
        Q = FREQ_INTERFERENCIA / LARGURA_REJEICAO_HZ if freq_relativa_target != 0 else 30.0
        # Gerar coeficientes do filtro Notch (b = numerador, a = denominador)
        b_notch, a_notch = iirnotch(w0, Q)
        print(f"Filtro Rejeita-Banda ativado para: {FREQ_INTERFERENCIA / 1e6:.3f} MHz")
    else:
        print("Aviso: Frequência do filtro fora do Span. Desativando filtro.")
        APLICAR_FILTRO_NOTCH = False

# =============================================================================
# 4. CONFIGURAÇÃO DOS PLOTS (ESPECTRO + WATERFALL)
# =============================================================================
fig, (ax_spec, ax_water) = plt.subplots(2, 1, figsize=(11, 8), gridspec_kw={'height_ratios': [1, 1.5]})
fig.suptitle("Análise de RFI e Espectrograma em Tempo Real", fontsize=14, fontweight='bold')

# Eixo de Frequências em MHz
freq_axis = np.fft.fftshift(np.fft.fftfreq(NUM_SAMPLES, 1/SAMPLE_RATE)) + CENTER_FREQ
freq_axis_mhz = freq_axis / 1e6

# Matriz inicializada com ruído base para o Waterfall
waterfall_matrix = np.full((WATERFALL_LINES, NUM_SAMPLES), -60.0)

# Linha do Espectro Instantâneo
line_spec, = ax_spec.plot(freq_axis_mhz, np.zeros(NUM_SAMPLES), color='crimson', linewidth=1.5)
ax_spec.set_title("Espectro de Potência Instantâneo")
ax_spec.set_ylabel("Potência Relativa (dBFS)")
ax_spec.set_ylim(-70, 20)
ax_spec.set_xlim(FREQ_START / 1e6, FREQ_STOP / 1e6)
ax_spec.grid(True)

# Imagem 2D para o Waterfall (Cascata)
# O colormap 'viridis' ou 'jet' mapeia a amplitude em dB para cores (Azul=Fraco, Vermelho=Forte)
im_water = ax_water.imshow(waterfall_matrix, aspect='auto', cmap='jet', vmin=-65, vmax=5,
                            extent=[FREQ_START / 1e6, FREQ_STOP / 1e6, WATERFALL_LINES, 0])
ax_water.set_title("Histórico Temporal (Waterfall)")
ax_water.set_xlabel("Frequência (MHz)")
ax_water.set_ylabel("Tempo (Linhas de Varredura)")

plt.tight_layout()
rx_buffer = bytearray(BUFFER_BYTES)

# =============================================================================
# 5. LOOP DE ATUALIZAÇÃO (ANIMAÇÃO)
# =============================================================================
def update(frame):
    global waterfall_matrix
    try:
        d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=1000)
        raw_data = np.frombuffer(rx_buffer, dtype=np.int16)
        
        # Sinais de quadratura complexos normalizados para escala dBFS
        iq_signal = (raw_data[0::2] + 1j * raw_data[1::2]) / 2048.0
        
        # --- Aplicação do Filtro Rejeita-Banda (Se ativo) ---
        if APLICAR_FILTRO_NOTCH:
            # lfilter aplica o filtro digital em tempo real no vetor de amostras complexas
            iq_signal = lfilter(b_notch, a_notch, iq_signal)
            
        # Cálculo do Espectro (FFT)
        fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
        psd = 10 * np.log10((np.abs(fft_data)**2) / NUM_SAMPLES + 1e-12)
        
        # Atualiza o gráfico de linha superior
        line_spec.set_ydata(psd)
        
        # Atualiza a matriz do Waterfall (Desloca as linhas antigas para baixo e insere a nova no topo)
        waterfall_matrix = np.roll(waterfall_matrix, 1, axis=0)
        waterfall_matrix[0, :] = psd
        
        # Atualiza a imagem com a matriz de dados nova
        im_water.set_array(waterfall_matrix)
        
    except Exception as e:
        print(f"\nErro no loop de varredura: {e}")
        
    return line_spec, im_water

ani = FuncAnimation(fig, update, interval=30, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nFechando monitor de RFI e desligando canal RX...")
    try:
        ch.enable = False
    except:
        pass
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

