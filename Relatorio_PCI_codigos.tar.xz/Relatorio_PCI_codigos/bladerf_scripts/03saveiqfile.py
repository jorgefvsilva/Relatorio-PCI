import bladerf
import numpy as np
import os
import sys

d = bladerf.BladeRF()
d.load_fpga('/home/jorge/Documents/0_PCI_INPE/BDA/Nuand-bladeRF/hostedxA4-latest.rbf')

# 2. Configurar os parâmetros do Canal RX1
ch = d.Channel(bladerf.CHANNEL_RX(0))

ch.frequency = 1405000000  # 1405 MHz em Hz
ch.sample_rate = 5000000   # 5 MHz (5 Msps) para a largura de banda
ch.bandwidth = 5000000     # Filtro interno de 5 MHz
ch.gain = 40               # Ganho inicial em dB (ajuste conforme necessário)

# 3. Configurar o Stream para recebimento de dados
# O bladeRF entrega amostras no formato SC16 Q11 (Shorts Intercalados: I, Q, I, Q...)
num_samples = 1024 * 64     # Tamanho do bloco de amostras
d.sync_config(
    layout=bladerf._bladerf.ChannelLayout.RX_X1, # Captura em 1 canal (RX1)
    fmt=bladerf._bladerf.Format.SC16_Q11,        # Formato de amostragem nativo
    num_buffers=16, 
    buffer_size=4096, 
    num_transfers=8,
    stream_timeout=1000  
)

# 4. Habilitar o canal RX1
ch.enable = True

# 5. Definir o arquivo de saída
output_filename = "captura_1405MHz.iq"
print(f"Iniciando gravação contínua em: {output_filename}")
print("Pressione Ctrl+C para interromper a captura a qualquer momento.\n")

# Alocar o buffer de transferência (4 bytes por amostra: 2 bytes I + 2 bytes Q)
buffer_samples = 1024 * 64
rx_buffer = bytearray(buffer_samples * 4)

total_bytes_saved = 0

try:
    # Abre o arquivo em modo de escrita binária ("wb")
    with open(output_filename, "wb") as f:
        while True:
            # Captura um bloco de amostras do bladeRF
            d.sync_rx(rx_buffer, buffer_samples, timeout_ms=1000)
            
            # Grava os bytes puros direto no disco (formato int16 intercalado I/Q)
            f.write(rx_buffer)
            
            # Atualiza o contador de dados salvos
            total_bytes_saved += len(rx_buffer)
            megabytes_saved = total_bytes_saved / (1024 * 1024)
            
            # Print dinâmico no terminal para acompanhar o tamanho do arquivo
            sys.stdout.write(f"\rTamanho do arquivo: {megabytes_saved:.2f} MB")
            sys.stdout.flush()

except KeyboardInterrupt:
    # Captura o Ctrl+C de forma limpa
    print("\n\nCaptura interrompida pelo usuário.")

finally:
    # 6. Garantir o fechamento seguro do hardware
    ch.enable = False
    print("Canal RX desabilitado. Arquivo salvo com sucesso!")


