import bladerf
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import time
import sys

# =============================================================================
# 1. PARÂMETROS DA VARREDURA LARGA (10 MHz a 1700 MHz)
# =============================================================================
FREQ_START = 100_000_000      # 10 MHz
FREQ_STOP  = 1100_000_000    # 1700 MHz (1.7 GHz)

# Largura de banda instantânea por salto (40 MHz para varredura rápida e estável)
STEP_BANDWIDTH = 40000000  
SAMPLE_RATE    = 40000000  

NUM_SAMPLES = 1024         # Resolução local de FFT por salto
BUFFER_BYTES = NUM_SAMPLES * 4
GAIN = 20                  # Ganho em dBWillful 
LIMIT_MIN_FREQ = 70000000  # Limite físico inferior do chip AD9361

# --- Configurações do Waterfall ---
WATERFALL_LINES = 80       # Quantidade de linhas históricas na cascata

# =============================================================================
# 2. CÁLCULO DOS PASSOS DA VARREDURA E GRADE GLOBAL
# =============================================================================
half_step = STEP_BANDWIDTH / 2
sweep_centers = np.arange(FREQ_START + half_step, FREQ_STOP, STEP_BANDWIDTH)
if sweep_centers[-1] + half_step < FREQ_STOP:
    sweep_centers = np.append(sweep_centers, FREQ_STOP - half_step)

num_steps = len(sweep_centers)
TOTAL_POINTS = NUM_SAMPLES * num_steps

print(f"--- Configuração do Analisador de Varredura Larga + Waterfall ---")
print(f"Banda Total: {FREQ_START/1e6:.1f} MHz até {FREQ_STOP/1e6:.1f} MHz")
print(f"Número de Saltos por ciclo: {num_steps}\n")

# =============================================================================
# 3. INICIALIZAÇÃO DO HARDWARE (MODO AUTOLOAD)
# =============================================================================
print("Inicializando o bladeRF...")
try:
    d = bladerf.BladeRF()
    ch = d.Channel(bladerf.CHANNEL_RX(0))
    ch.bandwidth = STEP_BANDWIDTH
    ch.gain_mode = bladerf._bladerf.GainMode.Manual
    ch.gain = GAIN
    d.set_sample_rate(0, SAMPLE_RATE)
    
    d.sync_config(
        layout=bladerf._bladerf.ChannelLayout.RX_X1,
        fmt=bladerf._bladerf.Format.SC16_Q11,
        num_buffers=16,
        buffer_size=4096,
        num_transfers=8,
        stream_timeout=500
    )
    ch.enable = True
    print("Hardware pronto para varredura!")
except Exception as e:
    print(f"\nErro crítico de inicialização: {e}")
    sys.exit(1)

# =============================================================================
# 4. CONFIGURAÇÃO DA INTERFACE GRÁFICA (ESPECTRO + WATERFALL)Willful 
# =============================================================================
fig, (ax_spec, ax_water) = plt.subplots(2, 1, figsize=(12, 8), gridspec_kw={'height_ratios': [1, 1.5]})
fig.suptitle("Analisador de Varredura Larga e Espectrograma", fontsize=14, fontweight='bold')

global_freq_axis = np.linspace(FREQ_START, FREQ_STOP, TOTAL_POINTS)
global_freq_mhz = global_freq_axis / 1e6

# Arrays globais persistentes em memória
global_psd = np.full(TOTAL_POINTS, -70.0)
waterfall_matrix = np.full((WATERFALL_LINES, TOTAL_POINTS), -65.0)

# Linha do Espectro Superior
line_spectrum, = ax_spec.plot(global_freq_mhz, global_psd, color='darkblue', linewidth=1)
ax_spec.set_title("Densidade Espectral de Potência Combinada (Mosaico de Varredura)")
ax_spec.set_ylabel("Potência Relativa (dBFS)")
ax_spec.set_xlim(FREQ_START / 1e6, FREQ_STOP / 1e6)
ax_spec.set_ylim(-70, 10)
ax_spec.grid(True)

# Imagem 2D do Waterfall Inferior (Mapeamento 'jet')
im_water = ax_water.imshow(waterfall_matrix, aspect='auto', cmap='jet', vmin=-65, vmax=5,
                            extent=[FREQ_START / 1e6, FREQ_STOP / 1e6, WATERFALL_LINES, 0])
ax_water.set_title("Histórico Temporal de Varredura Larga (Waterfall)")
ax_water.set_xlabel("Frequência (MHz)")
ax_water.set_ylabel("Ciclos de Varredura Completos")

plt.tight_layout()
rx_buffer = bytearray(BUFFER_BYTES)

# =============================================================================
# 5. LOOP DE VARREDURA EM BLOCO E ATUALIZAÇÃO DA TELA
# =============================================================================
IQ_SCALE = 2048.0
WATERFALL_REFRESH_INTERVAL = 3
FLUSH_DRAIN_COUNT = 1


def compute_psd_step(raw_buffer):
    """Converte o bloco RX em IQ e calcula a PSD com baixa alocação intermediária."""
    raw_iq = np.frombuffer(raw_buffer, dtype=np.int16).reshape(-1, 2)
    iq_signal = (raw_iq[:, 0].astype(np.float32) + 1j * raw_iq[:, 1].astype(np.float32)) / IQ_SCALE
    fft_data = np.fft.fftshift(np.fft.fft(iq_signal))
    power = np.abs(fft_data) ** 2
    return 10.0 * np.log10(np.maximum(power / NUM_SAMPLES, 1e-12))


def update(frame):
    global global_psd, waterfall_matrix

    # Faz um ciclo de varredura completo para atualizar o mosaico global.
    for step_idx, center_f in enumerate(sweep_centers):
        try:
            f_sintonia = LIMIT_MIN_FREQ if center_f < LIMIT_MIN_FREQ else center_f
            ch.frequency = int(f_sintonia)
            time.sleep(0.003)

            # Descarta apenas o mínimo necessário para limpar a fila antiga.
            for _ in range(FLUSH_DRAIN_COUNT):
                try:
                    d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=100)
                except Exception:
                    pass

            d.sync_rx(rx_buffer, NUM_SAMPLES, timeout_ms=500)
            psd_step = compute_psd_step(rx_buffer)

            if center_f < LIMIT_MIN_FREQ:
                psd_step = np.flip(psd_step)

            start_idx = step_idx * NUM_SAMPLES
            end_idx = start_idx + NUM_SAMPLES
            global_psd[start_idx:end_idx] = psd_step

        except Exception:
            continue

    line_spectrum.set_ydata(global_psd)

    if frame % WATERFALL_REFRESH_INTERVAL == 0:
        waterfall_matrix[1:, :] = waterfall_matrix[:-1, :]
        waterfall_matrix[0, :] = global_psd
        im_water.set_array(waterfall_matrix)
        return line_spectrum, im_water

    return line_spectrum,

# Inicializa o loop com cadência mais lenta para evitar que a atualização da UI
# domine o tempo de processamento do ciclo de varredura do hardware.
ani = FuncAnimation(fig, update, interval=40, blit=False, cache_frame_data=False)

def on_close(event):
    print("\nDesligando analisador de varredura com waterfall...")
    try:
        ch.enable = False
    except:
        pass
    sys.exit(0)

fig.canvas.mpl_connect('close_event', on_close)
plt.show()

