import matplotlib.pyplot as plt
import numpy as np
from pyuvdata import UVData

# 1. Load your realistic simulation
uv = UVData()
uv.read_uvh5("bdah5files/bda_realistic_solar_verify_Nblt.uvh5")

# 2. Extract U and V coordinates in wavelengths
# Use the center frequency of your 1400-1410 MHz band
freq_center = np.median(uv.freq_array)
lam = 3e8 / freq_center

u_wave = uv.uvw_array[:, 0] / lam
v_wave = uv.uvw_array[:, 1] / lam

# 3. Plot the UV-plane
plt.figure(figsize=(9, 9))

# Plot BDA baselines and their complex conjugates (symmetric points)
plt.scatter(u_wave, v_wave, s=5, color='navy', alpha=0.6, label='BDA Baselines')
plt.scatter(-u_wave, -v_wave, s=5, color='crimson', alpha=0.2, label='Conjugate Points')

plt.title(f"BDA UV-Coverage @ {freq_center/1e6:.1f} MHz\nPhase II 'T' Layout", fontsize=14)

# FIX: Added 'r' before the string to handle the LaTeX \lambda safely
plt.xlabel(r"U ($\lambda$)", fontsize=12)
plt.ylabel(r"V ($\lambda$)", fontsize=12)

plt.axis('equal')
plt.grid(True, linestyle=':', alpha=0.6)
plt.legend(loc='upper right')

plt.tight_layout()
plt.show()

print(f"✨ UV-Coverage plotted for {uv.Nbls} unique baselines.")
