import matplotlib.pyplot as plt
import numpy as np
from pyuvdata import UVData

# 1. Load the realistic solar uvh5 file
uv_read = UVData()
uv_read.read_uvh5("bda_realistic_solar_verify_Nblt.uvh5")

# 2. Setup Frequency axis
freq_mhz = uv_read.freq_array.flatten() / 1e6

# 3. Define the baselines we want to compare (Ant1, Ant2, Label, Color)
# These represent a mix of short, medium, and long baselines across the "T"
baselines_to_plot = [
    (0, 1, "Short (9m) - Unresolved", "blue"),
    (0, 4, "Medium (36m) - Partially Resolved", "green"),
    (0, 12, "Long E-W (126m) - Highly Resolved", "red"),
    (0, 25, "Long South (162m) - Maximum Resolution", "purple")
]

plt.figure(figsize=(12, 7))

for ant1, ant2, label, color in baselines_to_plot:
    # Find the data index for this specific pair
    idx = np.where((uv_read.ant_1_array == ant1) & (uv_read.ant_2_array == ant2))[0]

    if len(idx) > 0:
        # Extract first time step [0] and XX polarization [0]
        amp = np.abs(uv_read.data_array[idx[0], :, 0])
        plt.plot(freq_mhz, amp, label=label, color=color, lw=2, alpha=0.8)

# 4. Styling the Plot
plt.title("BDA Solar Model: Multi-Baseline Visibility Comparison", fontsize=15)
plt.xlabel("Frequency (MHz)", fontsize=12)
plt.ylabel("Visibility Amplitude (Jy)", fontsize=12)
plt.legend(loc='upper right', frameon=True, shadow=True)
plt.grid(True, linestyle=':', alpha=0.5)

# Highlight the 1400-1410 MHz range
plt.axvspan(1400, 1410, color='yellow', alpha=0.1, label='BDA Core Band')

plt.tight_layout()
plt.show()

# Quick Statistics Printout
for ant1, ant2, label, _ in baselines_to_plot:
    idx = np.where((uv_read.ant_1_array == ant1) & (uv_read.ant_2_array == ant2))[0]
    if len(idx) > 0:
        mean_amp = np.mean(np.abs(uv_read.data_array[idx[0], :, 0]))
        print(f"{label}: Mean Amplitude = {mean_amp:.1f} Jy")
