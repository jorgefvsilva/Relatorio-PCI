import numpy as np
import pandas as pd
from pyuvdata import UVData, Telescope
from astropy.coordinates import EarthLocation, get_sun
from astropy.time import Time
import astropy.units as u

# 1. Load the Surveyed GPS Data (from your PDF)
df = pd.read_csv("bda_antenna_geodetic_survey.csv")
print(len(df))
#avg_lat, avg_lon, avg_alt = df['LATITUDE(deg)'].mean(), df['LONGITUDE(deg)'].mean(), df['ALTITUDE(m)'].mean()
#center_loc = EarthLocation.from_geodetic(lat=avg_lat*u.deg,lon=avg_lon*u.deg, height=avg_alt*u.m) ## average center location
center_loc = EarthLocation.from_geodetic(lat=df['LATITUDE(deg)'][8]*u.deg,lon=df['LONGITUDE(deg)'][8]*u.deg,height=df['ALTITUDE(m)'][8]*u.m) ## antenna 09 center location

# 2. Rebuild Telescope with Correct 3.2.4 Metadata
tel = Telescope()
tel.name, tel.instrument, tel.location = "BDA", "BDA_L_Band", center_loc
tel.Nants, tel.x_orientation = len(df), "east"
tel.mount_type = np.array(["alt-az"] * len(df))

print(tel.Nants)

# Set Positions from GPS Survey
ant_locs = EarthLocation.from_geodetic(
    lat=df['LATITUDE(deg)'].values * u.deg,
    lon=df['LONGITUDE(deg)'].values * u.deg,
    height=df['ALTITUDE(m)'].values * u.m
)
tel.antenna_positions = np.stack([ant_locs.x.value - center_loc.x.value,
                                  ant_locs.y.value - center_loc.y.value,
                                  ant_locs.z.value - center_loc.z.value], axis=1)
tel.antenna_names, tel.antenna_numbers = df['Antenna'].tolist(), np.arange(len(df))

antpairs = [(2,10),(2,13),(2,16),(2,20),(2,21),(2,25),\
		(10,13),(10,16),(10,20),(10,21),(10,25),\
		(13,16),(13,20),(13,21),(13,25),\
		(16,20),(16,21),(16,25),\
		(20,21),(20,25),\
		(21,25)]
# 3. Setup Observation (1400 - 1410 MHz)
time_val = Time('2026-03-18T14:00:00', format='isot', scale='utc')
freqs = np.linspace(1400e6, 1410e6, 10) # High resolution 64 channels

uv = UVData.new(
    telescope=tel,
    freq_array=freqs,
    #times=np.linspace(time_val.jd, time_val.jd + 0.002, 10), # 10 time steps
    times=np.linspace(time_val.jd, time_val.jd + 0.1, 10),
    polarization_array=['xx'], #['xx', 'yy'],
    antpairs=antpairs,
    #do_blt_outer=True,
    #blts_are_rectangular=True
)

print(uv.Ntimes)
print(uv.Nblts)
#assert uv.Nblts == 3250 + 

# 4. Phase to the Sun
sun_pos = get_sun(time_val)
uv.phase(ra=sun_pos.ra.rad, dec=sun_pos.dec.rad, cat_name="The_Sun", epoch='J2000')

# 5. Physics: Solar Disk Resolution + System Noise
# Solar disk size ~0.53 degrees
sigma_rad = (0.53 * u.deg).to(u.rad).value / 2.35482
solar_flux_base = 10000.0 # 10,000 Jy (Quiet Sun L-Band)

uv.data_array = np.zeros((uv.Nblts, uv.Nfreqs, uv.Npols), dtype=np.complex64)

for i in range(uv.Nblts):
    lam = 3e8 / uv.freq_array.flatten()
    # Baseline distance in wavelengths
    uv_dist_sq = (uv.uvw_array[i, 0]/lam)**2 + (uv.uvw_array[i, 1]/lam)**2

    # 5a. Extended Source Visibility (Gaussian Disk)
    vis_amp = solar_flux_base * np.exp(-2 * np.pi**2 * uv_dist_sq * sigma_rad**2)

    # 5b. Add Realistic Noise (Thermal Noise floor ~4Jy per 1s)
    # Noise is complex: Real + i*Imag
    noise_level = 4.0
    sim_noise = (np.random.normal(scale=noise_level, size=(uv.Nfreqs, uv.Npols)) +
                 1j * np.random.normal(scale=noise_level, size=(uv.Nfreqs, uv.Npols)))

    # Inject Signal + Noise
    uv.data_array[i, :, :] = (vis_amp[:, np.newaxis] + sim_noise).astype(np.complex64)

# 6. Save and Verify
uv.flag_array = np.zeros(uv.data_array.shape, dtype=bool)
uv.nsample_array = np.ones(uv.data_array.shape, dtype=float)
uv.check()
uv.write_uvh5("bda_realistic_solar_verify_Nblt.uvh5", clobber=True, fix_autos=True)

print(f"✅ Realistic Solar Model saved (1400-1410 MHz).")
print(f"Noise floor: {noise_level} Jy | Peak Solar Flux: {solar_flux_base} Jy")
